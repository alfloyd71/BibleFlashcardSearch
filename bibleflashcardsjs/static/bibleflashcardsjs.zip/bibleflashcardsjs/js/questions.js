let myFlashCards = [
       {question:"But seek ye first the kingdom of God, and his righteousness; and all these things shall be added unto you.",
        answer:"Matthew 6:33 KJV", box:2}, 
       {question:"And fear not them which kill the body, but are not able to kill the soul: but rather fear him which is able to destroy both soul and body in hell. - Mat 10:28 KJV",
        answer:"Matthew 10:28 KJV", box:5},  
        
    
    ];